// JavaScript Document



var dataProduct = JSON.parse(localStorage.getItem('storage_dataProduct'));
var dataAudit = JSON.parse(localStorage.getItem('storage_dataAudit'));

var auditIndex = 0;
var auditType = '';

var auditNew;

var auditSetItem = 0;
var auditPointStatus = "new";

var auditPointX, auditPointY;
var auditRamblerX, auditRamblerY;

var dataCompetitor = [
    {
        name: "Muscle Pharm",
        subname: "Lorem ipsum dolor",
    },
    {
        name: "Optimum Nutrition",
        subname: "Lorem ipsum dolor",
    },
    {
        name: "My Protein",
        subname: "Lorem ipsum dolor",
    },
    {
        name: "Weider",
        subname: "Lorem ipsum dolor",
    },
    {
        name: "Dymatize Nutrition",
        subname: "100% Whey Protein Isolate",
    },
    {
        name: "Costco",
        subname: "Lorem ipsum dolor",
    },
];

var dataPromo = [
    {
        name: "Go Bar",
        subname: "Tart Cherry & Pistacio",
    },
    {
        name: "Yeti Bar",
        subname: "Tart Cherry & Sunflower",
    },
    {
        name: "Astra",
        subname: "Tart Cherry & Sunflower",
    },
];

var dataPOS = [
    {
        name: "Leaflet",
        subname: "",
    },
    {
        name: "Table Stand",
        subname: "",
    },
    {
        name: "Poster",
        subname: "",
    },
    {
        name: "Banner",
        subname: "",
    },
];

var setPointItem = new Object();
var setAuditItem = new Object();




localStorage.setItem('storage_indexSlide', '4');



// ====================================================================================================  Init  Scroller
var scrollerGallery,
    scrollerProd;


function InitScroller() {

    scrollerProd = new IScroll('#popup_list', {
        scrollbars: 'custom',
        click: true,
    });

    scrollerGallery = new IScroll('#loc_gallery', {
        eventPassthrough: true,
        scrollX: true,
        scrollY: false,
        preventDefault: false,
        scrollbars: false,
        click: true,
    });

};






// ==============================================================================================    Init Click Gallery
function InitClickPopupList(objPoint) {

    objPoint.on("click", function(e){
        objPoint.toggleClass('checkOnn');
    });
};



// ========================================================================================================  Load Point
function LoadPoint() {
    var PointHTML = '';

    switch (auditType) {
        case "products":
            for(var i = 0; i < dataProduct.length; i++) {
                PointHTML += '<li class="item_listing" data-index="'+i+'">' +
                    '<h5>'+ dataProduct[i].name +'</h5>' +
                    '<p>'+ dataProduct[i].subname +'</p>' +
                    '</li>';
            };
            break;
        case "competitors":
            for(var i = 0; i < dataCompetitor.length; i++) {
                PointHTML += '<li class="item_listing" data-index="'+i+'">' +
                    '<h5>'+ dataCompetitor[i].name +'</h5>' +
                    '<p>'+ dataCompetitor[i].subname +'</p>' +
                    '</li>';
            };
            break;
        case "promo":
            for(var i = 0; i < dataPromo.length; i++) {
                PointHTML += '<li class="item_listing" data-index="'+i+'">' +
                    '<h5>'+ dataPromo[i].name +'</h5>' +
                    '<p>'+ dataPromo[i].subname +'</p>' +
                    '</li>';
            };
            break;
        default:
            for(var i = 0; i < dataPOS.length; i++) {
                PointHTML += '<li class="item_listing" data-index="'+i+'">' +
                    '<h5>'+ dataPOS[i].name +'</h5>' +
                    '<p>'+ dataPOS[i].subname +'</p>' +
                    '</li>';
            };
    };
    $("#popup_list ul.scroller").html(PointHTML);


    if( auditPointStatus==="old" ) {
        for(var k = 0; k < dataAudit[auditIndex].set_point[auditSetItem].list.length; k++) {
            $('ul.scroller li:nth-child('+ (dataAudit[auditIndex].set_point[auditSetItem].list[k]+1) +')').addClass("checkOnn");
        };
    };


    $("#popup_list ul.scroller li").each(function( index ) {
        InitClickPopupList($(this));
    });

    setTimeout( function() {
        scrollerProd.refresh();
        scrollerProd.scrollTo(0, 0, 700, IScroll.utils.ease.back);
    }, 200);


    $(".audit_anchor h3").html(auditType);

    document.getElementById("audit_anchor").className = "audit_anchor";

    if( auditPointX>282 ) {
        $(".audit_anchor").addClass("left").css({"top": (auditPointY+40)+"px", "left": (auditPointX-20)+"px"});
    }else {
        $(".audit_anchor").addClass("right").css({"top": (auditPointY+40)+"px", "left": (auditPointX+90)+"px"});
    };

    if( auditPointY<187 ) {
        $(".audit_popup").css({"margin-top": (187-auditPointY)+"px"});
    }else if( auditPointY>501 ) {
        $(".audit_popup").css({"margin-top": (501-auditPointY)+"px"});
    }
    else  $(".audit_popup").css({"margin-top": "0px"});

    $(".popup_over").addClass("active");

};



// ==============================================================================================    Init Click Gallery
function InitClickAuditPoint(objPoint) {

    objPoint.on("click", function(e){
        auditPointStatus = "old";
        auditType = objPoint.attr("data-typpe");
        auditPointX = parseInt(objPoint.attr("data-x"));
        auditPointY = parseInt(objPoint.attr("data-y"));
        auditSetItem = parseInt(objPoint.attr("data-inset"));

        objPoint.addClass("current");

        LoadPoint();
    });
};



// ====================================================================================================== Load Location
function LoadLocation() {

    $(".audit_image").removeClass("zoomIn").addClass("zoomOut");

    setTimeout( function() {
        $(".audit_image img").attr({"src": dataAudit[auditIndex].loc_visual});
        $(".audit_image").removeClass("zoomOut").addClass("zoomIn");
    }, 600);

    $(".audit_point").remove();

    for(var n = 0; n < dataAudit[auditIndex].set_point.length; n++) {

        $('<div class="audit_point hidden '+ dataAudit[auditIndex].set_point[n].type +' '+ dataAudit[auditIndex].set_point[n].status +'" data-typpe="'+ dataAudit[auditIndex].set_point[n].type +'" ' +
                    'data-inset="'+ n +'" data-x="'+ dataAudit[auditIndex].set_point[n].x +'" data-y="'+ dataAudit[auditIndex].set_point[n].y +'"/>')
            .css({"top": dataAudit[auditIndex].set_point[n].y+"px", "left": dataAudit[auditIndex].set_point[n].x+"px"})
            .html(dataAudit[auditIndex].set_point[n].name)
            .appendTo("#audit");
    };

    $(".rambler_li").removeClass("full").addClass("empty");

    $(".audit .audit_point").each(function( index ) {
        if( $(this).hasClass("full") ) {                                                                                console.log($(this).hasClass("full"));
            $(".rambler_li."+$(this).attr("data-typpe")).removeClass("empty").addClass("full");
        };
        InitClickAuditPoint($(this));
    });

    setTimeout( function() {
        $(".audit_point").removeClass("hidden");
    }, 600);
};



// ========================================================================================================= Load Audit
function LoadAudit() {

    $(".audit_point").remove();

    for(var n = 0; n < dataAudit[auditIndex].set_point.length; n++) {

        $('<div class="audit_point '+ dataAudit[auditIndex].set_point[n].type +' '+ dataAudit[auditIndex].set_point[n].status +'" data-typpe="'+ dataAudit[auditIndex].set_point[n].type +'"' +
                    ' data-inset="'+ n +'" data-x="'+ dataAudit[auditIndex].set_point[n].x +'" data-y="'+ dataAudit[auditIndex].set_point[n].y +'"/>')
            .css({"top": dataAudit[auditIndex].set_point[n].y+"px", "left": dataAudit[auditIndex].set_point[n].x+"px"})
            .html(dataAudit[auditIndex].set_point[n].name)
            .appendTo("#audit");
    };

    $(".rambler_li").removeClass("full").addClass("empty");

    $(".audit .audit_point").each(function( index ) {
        if( $(this).hasClass("full") ) {                                                                                console.log($(this).hasClass("full"));
            $(".rambler_li."+$(this).attr("data-typpe")).removeClass("empty").addClass("full");
        };
        InitClickAuditPoint($(this));
    });
};



// ==============================================================================================    Init Click Gallery
function InitClickGallery(objPoint) {

    objPoint.on("click", function(e){
        auditIndex = parseInt(objPoint.attr("data-index"));

        $(".item_gallery").removeClass('active');
        objPoint.addClass('active');

        LoadLocation();
    });
};



// ======================================================================================================  Load Gallery
function LoadGallery() {
    var GalleryHTML = '';

    for(var i = 0; i < dataAudit.length; i++) {

        GalleryHTML += '<li class="item_gallery" data-index="'+i+'">' +
                            '<img src="'+ dataAudit[i].loc_visual +'">' +
                        '</li>';
    };

    $("#loc_gallery ul.scroller-h").html(GalleryHTML).css({"width": ($(".item_gallery").length * 180 + 40)+"px"});      console.log("item_gallery = "+$(".item_gallery").length);
    $("ul.scroller-h li:first-child").addClass("active");

    $("#loc_gallery li").each(function( index ) {
        InitClickGallery($(this));
    });

    setTimeout( function() {
        scrollerGallery.refresh();
    }, 200);
};





// ==============================================================================================
// ==============================================================================================
// ==============================================================================================

$(document).ready(function(){

// ==============================================================================================  SETUP
    setTimeout( function() {
        InitScroller();
    }, 100);

    setTimeout( function() {
        $("nav, .gallery").addClass('onStage');
    }, 400);

    LoadGallery();
    LoadLocation();



// ==============================================================================================  menu
    document.getElementById("btn_menu").addEventListener('click', function(event) {
        $("nav, .gallery").toggleClass('onStage');
    });

    document.getElementById("logo").addEventListener('click', function(event) {
        $("nav, .gallery").removeClass('onStage');
    });



// ==============================================================================================  audit
    $("#audit_work_field").on("click", function(e){
        $(".audit_varambler").removeClass("active");

        auditPointX = ( e.pageX<71 ) ? 31 : ( e.pageX>953 ) ? 913 : (e.pageX-40);
        auditPointY = ( e.pageY<71 ) ? 31 : ( e.pageY>697 ) ? 657 : (e.pageY-40);                                          console.log(e.pageX); console.log(e.pageY);

        auditRamblerX = ( e.pageX<172 ) ? 132 : ( e.pageX>852 ) ? 812 : (e.pageX-40);
        auditRamblerY = ( e.pageY<172 ) ? 132 : ( e.pageY>596 ) ? 556 : (e.pageY-40);

        $(".audit_varambler").css({"top": auditRamblerY+"px", "left": auditRamblerX+"px"});

        setTimeout( function() {
            $(".audit_varambler").addClass("active");
        }, 100);
    });


    $("#btn_rambler_close").on("click", function(e){
        $(".audit_varambler").removeClass("active").css({"top": "-3000px", "left": "0px"});
    });


    var ramblerBtns = getElementsByClassName("rambler_li");
    ///////////////////////////////////
    for(var i = 0; i < ramblerBtns.length; i++) {
        ramblerBtns[i].addEventListener('click', function(event) {
            var ramblerType = this.getAttribute("data-typpe");

            if( $(".rambler_li."+ramblerType).hasClass("empty") ) {
                auditPointStatus = "new";
                auditType = ramblerType;
                $(".audit_varambler").removeClass("active").css({"top": "-3000px", "left": "0px"});

                auditNew = $('<div class="audit_point current '+ auditType +'" data-typpe="'+ auditType +'" data-x="'+ auditPointX +'" data-y="'+ auditPointY +'" ' +
                            'data-inset="'+ dataAudit[auditIndex].set_point.length +'"/>')
                    .css({"top": auditPointY+"px", "left": auditPointX+"px"})
                    .html(this.innerHTML)
                    .appendTo("#audit");

                LoadPoint();
                InitClickAuditPoint(auditNew);
            };
        });
    };



// ==============================================================================================  audit popup
    function CreateAuditData() {
        var currentPointStatus = '';
                                                                                                                        console.log("auditPointStatus = "+auditPointStatus);
        if( auditPointStatus==="new" ) {
            setPointItem = new Object();

            setPointItem.x = auditPointX;
            setPointItem.y = auditPointY;
            setPointItem.type = auditType;
            setPointItem.name = auditNew.html();
            setPointItem.list = [];                                                                                     console.log("auditIndex = "+auditIndex);

            $("#popup_list ul.scroller li.checkOnn").each(function( ind ) {
                setPointItem.list[ind] = parseInt($(this).attr("data-index"));
            });                                                                                                         console.log("setPointItem.list.length = "+setPointItem.list.length);

            setPointItem.status = ( setPointItem.list.length>0 ) ? "full" : "empty";
            $(".audit_point.current").removeClass("full").removeClass("empty").addClass(setPointItem.status);

            currentPointStatus = setPointItem.status;

            dataAudit[auditIndex].set_point.push(setPointItem);
            localStorage.setItem('storage_dataAudit', JSON.stringify(dataAudit));
        }
        else {
            dataAudit[auditIndex].set_point[auditSetItem].list = [];                                                    console.log("auditIndex = "+auditIndex);

            $("#popup_list ul.scroller li.checkOnn").each(function( ind ) {
                dataAudit[auditIndex].set_point[auditSetItem].list[ind] = parseInt($(this).attr("data-index"));
            });                                                                                                         console.log(dataAudit[auditIndex].set_point[auditSetItem].list.length);

            dataAudit[auditIndex].set_point[auditSetItem].status = ( dataAudit[auditIndex].set_point[auditSetItem].list.length>0 ) ? "full" : "empty";
            $(".audit_point.current").removeClass("full").removeClass("empty").addClass(dataAudit[auditIndex].set_point[auditSetItem].status);

            currentPointStatus = dataAudit[auditIndex].set_point[auditSetItem].status;

            localStorage.setItem('storage_dataAudit', JSON.stringify(dataAudit));
        };

        $(".rambler_li."+$(".audit_point.current").attr("data-typpe")).removeClass("empty").removeClass("full").addClass(currentPointStatus);


        document.getElementById("audit_anchor").className = "audit_anchor";
        $(".audit_anchor").css({"top": "-3000px", "left": "0px"});
        $(".popup_over").removeClass("active");

        $(".audit_point").removeClass("current");
    };


    document.getElementById("btn_popup_submit").addEventListener('click', function(event) {
        CreateAuditData();                                                                                              console.log(JSON.stringify(dataAudit[auditIndex].set_point));
    });
    document.getElementById("popup_over").addEventListener('click', function(event) {
        CreateAuditData();                                                                                              console.log(JSON.stringify(dataAudit[auditIndex].set_point));
    });


    document.getElementById("btn_delete").addEventListener('click', function(event) {
        var insetIndex = parseInt($(".audit_point.current").attr("data-inset"));

        dataAudit[auditIndex].set_point.splice(insetIndex, 1);
        localStorage.setItem('storage_dataAudit', JSON.stringify(dataAudit));

        $(".audit_point.current").remove();

        document.getElementById("audit_anchor").className = "audit_anchor";
        $(".audit_anchor").css({"top": "-3000px", "left": "0px"});
        $(".popup_over").removeClass("active");                                                                         console.log(JSON.stringify(dataAudit[auditIndex].set_point));

        LoadAudit();
    });




// ===================================================================================================  create location
    //-------------------------------------------------------------------------------- JS Bridge
    document.addEventListener('WebViewJavascriptBridgeReady', function(event) {
        //---------------------------------------------------------------------------- create photo
        document.getElementById("btn_photo").addEventListener('click', function(event) {                             			console.log('photo_create clicked');

            ctm.photo(function(result){
                resultPhoto = result;
                //resultPhoto = 'images/test.jpg'; //console.log(result);

                if( resultPhoto!=='' ) {
                    setAuditItem = new Object(
                        {
                            loc_name: '',
                            loc_visual: resultPhoto,
                            set_point: [],
                        }
                    );
                    dataAudit.unshift(setAuditItem);
                    localStorage.setItem('storage_dataAudit', JSON.stringify(dataAudit));

                    LoadGallery();
                    LoadLocation();

                    setTimeout( function() {
                        scrollerGallery.refresh();
                    }, 200);
                };
            });//ctm.photo
            return false;

        });// btn_photo
    }); // WebViewJavascriptBridgeReady





// ==============================================================================================

});








