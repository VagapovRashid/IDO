// JavaScript Document



var dataProduct = JSON.parse(localStorage.getItem('storage_dataProduct'));

var selectedCategory = localStorage.getItem('storage_selectedCategory');

var selectedProd = 0;




// ==============================================================================================  Keyboard Show Close Press Key
// ==============================================================================================   
// ==============================================================================================  
var inputRem = '',
    inputNew = '';
var activeInputField,
    typeKeyInput;


function KeyboardShow() {
    var inputPos = activeInputField.offset(),
        inputTop = inputPos.top,
        inputLeft = inputPos.left,
        inputWidth = activeInputField.outerWidth();
    var keyboardLeft = 0,
        keyboardTop = 0,
        keyboardSide = '';                                                                                          console.log( 'KeyboardShow inputPos = '+inputLeft+" "+inputTop );

    document.getElementById("keyboard").className = "keyboard";

    if( inputLeft>450 ) {
        keyboardLeft = inputLeft-242;
        keyboardSide = 'from_left';
    }else {
        keyboardLeft = inputLeft+inputWidth+21;
        keyboardSide = 'from_right';
    };                                                                                                              console.log( 'KeyboardShow keyboardPos = '+keyboardLeft+" "+keyboardSide );

    if( inputTop<180 ) {
        keyboardTop = 30;
        $(".keyboard .arrow").css({"top":(inputTop-30+18)+'px'});
    }else if( inputTop>608 ) {
        keyboardTop = 462;
        $(".keyboard .arrow").css({"top":(inputTop-462+18)+'px'});
    }else {
        keyboardTop = inputTop-130;
        $(".keyboard .arrow").css({"top":'50%'});
    };                                                                                                              console.log( 'KeyboardShow keyboardPos = '+keyboardTop );

    $(".keyboard").css({"left":keyboardLeft+'px', "top":keyboardTop+'px'});
    $(".keyboard").addClass(keyboardSide).addClass("show");
    setTimeout( function() {
        $(".keyboard_over").addClass("active");
    }, 200);
};


function KeyboardClose() {
    $(".keyboard").css({"left":'0px', "top":'-3000px'});
    document.getElementById("keyboard").className = "keyboard";
    $(".keyboard .symb").removeClass("press");
    $(".qte .input").removeClass("active_input");
    $(".keyboard_over").removeClass("active");

    if( inputRem=='' ) {
        inputRem = '0';
        $("#input_"+selectedProd).html(inputRem);
    };
                                                                                                                        console.log( 'selectedProd = '+selectedProd );
    $("#input_"+selectedProd).attr({"data-val": parseInt(inputRem)});
    $("#hammer_"+selectedProd).attr({"data-val": parseInt(inputRem)});

    dataProduct[selectedProd].order = parseInt(inputRem);
    localStorage.setItem('storage_dataProduct', JSON.stringify(dataProduct));

    if( dataProduct[selectedProd].order>0 ) $("#product_"+selectedProd).addClass("inOrder");
    else                                    $("#product_"+selectedProd).removeClass("inOrder");
};


function KeyboardPress(objKey) {
    var symbValue = objKey.getAttribute("data-symb");

    $(".keyboard span").removeClass("press");
    objKey.className += ' press';

    switch (symbValue) {
        case 'c':
            inputNew = inputRem.slice(0, -1);
            inputRem = inputNew;
            break;
        case 'x':
            KeyboardClose();
            break;
        default:
            inputNew = inputRem + symbValue;
            if( inputNew.length==2 && inputNew.substr(0, 1)=='0' ) {
                inputRem = inputNew.substr(1);
            }
            else if( inputNew.length>3 ) {
                inputRem = inputNew.substr(0, 3);
            }
            else inputRem = inputNew;
    };
    activeInputField.html(inputRem);

};


function Keyboard() {
    activeInputField = $(".qte .active_input");
    inputRem = activeInputField.attr("data-val");
    inputNew = '';                                                                                                       console.log( 'Keyboard inputRem = '+inputRem );
    KeyboardShow();
};


function InitKeyInput(objInput, typeInput) {                                                                                console.log("InitKeyInput!!!");

    objInput.on("click", function(e){

        $(".qte .input").removeClass("active_input");
        objInput.addClass("active_input");

        typeKeyInput = typeInput;
        selectedProd = parseInt(objInput.attr("data-index"));                                                               console.log( 'selectedProd = '+selectedProd );
        Keyboard();
    });
};
// ==============================================================================================  
// ==============================================================================================  
// ==============================================================================================  





// ==============================================================================================  Init  Scroller
var scrollerProd;


function InitScroller() {

    scrollerProd = new IScroll('#scroller_product', {
        scrollbars: false,
        click: true,
    });

};



// ============================================================================================== Summary
function Summary() {
    var totalInCart = 0;

    for(var keyCategory in dataProduct) {
        for(var z = 0; z < dataProduct[keyCategory].length; z++) {
            if( dataProduct[keyCategory][z].order>0 ) totalInCart ++;
        };
    };
    $("#amount_cart").html(totalInCart);

    if( totalInCart>0 ) $("#amount_cart").addClass("full");
    else                $("#amount_cart").removeClass("full");
};



// ==============================================================================================  Field Hammer
var EV_deltaX = 0;

function FieldHammer(el, topLimit, Step, Inter) {
    var mc = new Hammer(el, {});

    var singleTap = new Hammer.Tap({ event: 'singletap' });
    var onlyPan = new Hammer.Pan({event: 'onlypan' });
    mc.add([onlyPan, singleTap]);
    singleTap.requireFailure(onlyPan);

    mc.get('pan').set({ direction: Hammer.DIRECTION_HORIZONTAL });

    mc.on("tap", function(ev) {
        ev.preventDefault();
        selectedProd = parseInt(el.getAttribute('data-index'));
        localStorage.setItem('storage_selectedProd', selectedProd);                                                         console.log(selectedCategory); console.log(selectedProd);
        localStorage.setItem('storage_selectedCategory', selectedCategory);
        CTAPPgoToSlide('11');
    });

    mc.on("panleft", function(ev) {
        ev.preventDefault();
        var valFieldHammer = parseInt(el.getAttribute('data-val'));
        var $FieldInput = $("#"+el.getAttribute('data-connect'));

        if( Math.abs(ev.deltaX-EV_deltaX)>Inter ) {
            EV_deltaX = ev.deltaX;
            valFieldHammer = valFieldHammer - Step;
            valFieldHammer = ( valFieldHammer<0 ) ? 0 : valFieldHammer;

            el.setAttribute('data-val', valFieldHammer);
            $FieldInput.attr({"data-val": valFieldHammer}).html(valFieldHammer);
        };
    });

    mc.on("panright", function(ev) {
        ev.preventDefault();
        var valFieldHammer = parseInt(el.getAttribute('data-val'));
        var $FieldInput = $("#"+el.getAttribute('data-connect'));

        if( Math.abs(ev.deltaX-EV_deltaX)>Inter ) {
            EV_deltaX = ev.deltaX;
            valFieldHammer = valFieldHammer + Step;
            valFieldHammer = ( valFieldHammer>topLimit ) ? topLimit : valFieldHammer;

            el.setAttribute('data-val', valFieldHammer);
            $FieldInput.attr({"data-val": valFieldHammer}).html(valFieldHammer);                                                                 // console.log(valHammer);
        };
    });

    mc.on("panend", function(ev) {
        EV_deltaX = 0;																										console.log("panend");
        var valFieldHammer = parseInt(el.getAttribute('data-val'));
        var prodIndex = parseInt(el.getAttribute('data-index'));

        dataProduct[prodIndex].order = valFieldHammer;
        localStorage.setItem('storage_dataProduct', JSON.stringify(dataProduct));

        if( valFieldHammer>0 ) $("#product_"+prodIndex).addClass('inOrder');
        else                   $("#product_"+prodIndex).removeClass('inOrder');

        Summary();
    });
};



// ===================================================================================================  Load Catalog
function LoadCatalog() {
    var CatalogHTML = '';
    var prodOrdered = '';

    for(var n = 0; n < dataProduct.length; n++) {
        prodOrdered = ( dataProduct[n].order>0 ) ? 'inOrder' : '';

        CatalogHTML += '<div class="product show '+ prodOrdered +' '+ dataProduct[n].category +'" id="product_'+n+'" data-index="'+n+'" data-cat="'+dataProduct[n].category+'">' +
                            '<img class="product_img" src="images/product/'+ dataProduct[n].category +'/'+ dataProduct[n].image[0] +'">' +
                            '<h4>'+
                                '<span>'+dataProduct[n].name+'</span>' +
                                '<span>€ '+dataProduct[n].price+'</span>' +
                            '</h4> ' +
                            '<div class="parametr">' +
                                '<span>'+ dataProduct[n].subname +'</span>' +
                                '<span>'+ dataProduct[n].format +'</span>' +
                            '</div> ' +
                            '<div class="product_rate" style="width: '+ (dataProduct[n].rate*16) +'px;"></div> ' +
                            '<div class="qte">' +
                                '<div class="input" id="input_'+n+'" data-connect="hammer_'+n+' "data-index="'+n+'" data-val="'+ dataProduct[n].order +'">' +
                                    dataProduct[n].order +
                                '</div>' +
                            '</div>' +
                            '<div class="hammer" id="hammer_'+n+'" data-connect="input_'+n+'" data-index="'+n+'" data-val="'+dataProduct[n].order+'"></div>' +
                        '</div>';
    };

    $("#scroller_product .scroller").html(CatalogHTML);

    $("#scroller_product .product").each(function( index ) {
        FieldHammer(document.getElementById("hammer_"+index), 999, 1, 20);
        InitKeyInput($("#input_"+index), 'string');
    });


    if( selectedCategory==='' ) {
        $('ul li.item-category').removeClass("active");
        document.getElementById("menu_category").className = "menu_category";
        $('#title').html("All Products");
    }
    else {
        $('ul li[data-category="'+ selectedCategory +'"]').addClass("active");
        document.getElementById("menu_category").className = "menu_category " + $('ul li.item-category.active').attr("data-pos");
        $('#title').html($('ul li.item-category.active span').html());

        $("#scroller_product .product").removeClass("show");
        $("#scroller_product .product."+selectedCategory).addClass("show");
    };

    $('#amount_prod').html("("+$('.product.show').length+")");

    setTimeout( function() {
        scrollerProd.refresh();
        scrollerProd.scrollTo(0, 0, 700, IScroll.utils.ease.back);
    }, 100);
};






// ==============================================================================================
// ==============================================================================================
// ==============================================================================================

$(document).ready(function(){

// ==============================================================================================  SETUP
    setTimeout( function() {
        InitScroller();
    }, 100);


    LoadCatalog();
    Summary();

    localStorage.setItem('storage_indexSlide', "2");



// ==============================================================================================  Keyboard
    var symbBtns = getElementsByClassName("symb");
    ///////////////////////////////////
    for(var i = 0; i < symbBtns.length; i++) {
        symbBtns[i].addEventListener('click', function(event) {
            KeyboardPress(this);
        });
    };

    document.getElementById("keyboard_over").addEventListener('click', function(event) {
        KeyboardClose();
    });



// ==============================================================================================  category menu
    var categoryBtns = getElementsByClassName("item-category");
    ///////////////////////////////////
    for(var i = 0; i < categoryBtns.length; i++) {
        categoryBtns[i].addEventListener('click', function(event) {

            if( this.className==="item-category" ) {
                $(".item-category").removeClass('active');
                this.className += ' active';
                document.getElementById("menu_category").className = "menu_category " + this.getAttribute("data-pos");

                selectedCategory = this.getAttribute("data-category");                                                  console.log( 'selectedCategory if = '+selectedCategory);
                $('#title').html($('ul li.item-category.active span').html());

                $(".product").removeClass("show");
                $(".product."+selectedCategory).addClass("show");
            }
            else {
                $(".item-category").removeClass('active');
                document.getElementById("menu_category").className = "menu_category";

                selectedCategory = "";                                                                                  console.log( 'selectedCategory else = '+selectedCategory);
                $('#title').html("All Products");

                $(".product").addClass("show");
            };//if

            $('#amount_prod').html("("+$('.product.show').length+")");
            localStorage.setItem('storage_selectedCategory', selectedCategory);

            setTimeout( function() {
                scrollerProd.refresh();
                scrollerProd.scrollTo(0, 0, 700, IScroll.utils.ease.back);
            }, 100);
        });
    };



// ==============================================================================================

});








