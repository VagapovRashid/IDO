// JavaScript Document


localStorage.setItem('storage_indexSlide', '1');



// ==============================================================================================  Init  Scroller
var scrollerStage,
    scrollerProd;


function updatePosition() {                                                                                                //console.log(this.y>>0);

    if( this.y>-60 ) {
        $(".navigate, .logo, .cart").addClass('onStage');
    }else {
        $(".navigate, .logo, .cart").removeClass('onStage');
    };

    if( this.y<(-2100) ) {
        $(".section-steps .back, .section-steps .text_content").addClass('fadeIn');
        $('.section-steps h1 p').textillate({
            initialDelay: 0,
            in: {
                effect: 'zoomInDown',
                delayScale: 5,
                delay: 20,
            }
        });
    }
    else if( this.y<(-1470) ) {
        $('#line_prod').addClass('fadeIn');
        $('#line_prod .product').addClass('zoomInRight');
    }
    else if( this.y<(-1250) ) {
        $(".section-product .frame").addClass('fadeInLeft');
        $('.section-product .text_content, .section-product .subtitle').addClass('fadeIn');
        $('.section-product h2 p').textillate({
            initialDelay: 0,
            in: {
                effect: 'zoomInRight',
                delayScale: 5,
                delay: 20,
            }
        });
    }
    else if( this.y<(-890) ) {
        $('.section-about img.animated').addClass('fadeIn');
    }
    else if( this.y<(-520) ) {
        $('.ingredient li').addClass('zoomInUp');
    }
    else if( this.y<(-260) ) {
        $(".section-about .frame").addClass('fadeInLeft');
        $('.section-about .text_content, .section-about .subtitle').addClass('fadeIn');
        $('.section-about h2 p').textillate({
            initialDelay: 0,
            in: {
                effect: 'zoomInRight',
                delayScale: 5,
                delay: 20,
            }
        });
    };
};



function InitScroller() {

    scrollerStage = new IScroll('#Stage_base', {
        scrollbars: false,
        click: true,
        probeType: 3
    });
    scrollerStage.on('scroll', updatePosition);
    scrollerStage.on('scrollEnd', updatePosition);

    scrollerProd = new IScroll('#line_prod', {
        eventPassthrough: true,
        scrollX: true,
        scrollY: false,
        preventDefault: false,
        scrollbars: false,
        click: true,
    });

};



// ==============================================================================================                                        Init Click Product  
function InitClickProduct(objProd) {

    objProd.on("click", function(e){

        selectedProd = parseInt(objProd.attr("data-index"));
        localStorage.setItem('storage_selectedProd', selectedProd);

        objProd.addClass("inOrder");

        setTimeout( function() {
            CTAPPgoToSlide('11');
        }, 1000);
    });
};



// ==============================================================================================  Load Catalog
var setProduct = [0,3,6,12,18,22,26,28,30,36];

function LoadCatalog() {
    var n = 0;
    var CatalogHTML = '';

    for(var m = 0; m < 10; m++) {
        n = setProduct[m];

        CatalogHTML += '<div class="product animated '+ dataProduct[n].category +'" id="product_'+n+'" data-index="'+n+'" data-cat="'+dataProduct[n].category+'">' +
                            '<img class="product_img" src="images/product/'+ dataProduct[n].category +'/'+ dataProduct[n].image[0] +'">' +
                            '<h4>'+
                                '<span>'+dataProduct[n].name+'</span>' +
                                '<span>€ '+dataProduct[n].price+'</span>' +
                            '</h4> ' +
                            '<div class="parametr">' +
                                '<span>'+ dataProduct[n].subname +'</span>' +
                                '<span>'+ dataProduct[n].format +'</span>' +
                            '</div> ' +
                            '<div class="product_rate" style="width: '+ (dataProduct[n].rate*16) +'px;"></div> ' +
                        '</div>';
    };
    $("#line_prod .scroller-h").html(CatalogHTML);

    $("#line_prod .product").each(function( index ) {															 
        InitClickProduct($(this));
    });

    $("#line_prod .scroller-h").css({"width": ($("#line_prod .scroller-h .product").length * 200 + 190)+"px"});

    setTimeout( function() {
        scrollerProd.refresh();
    }, 300);
};








// ==============================================================================================
// ==============================================================================================
// ==============================================================================================

$(document).ready(function(){

// ==============================================================================================  SETUP
    setTimeout( function() {
        InitScroller();
    }, 100);

    setTimeout( function() {
        $(".navigate, .logo, .cart").addClass('onStage');
    }, 1200);

    $('.section-great h1 p').textillate({
        initialDelay: 0,
        in: {
            effect: 'zoomInDown',
            delayScale: 5,
            delay: 20,
        }
    });


    LoadCatalog();



// ==============================================================================================  menu
    document.getElementById("btn_menu").addEventListener('click', function(event) {
        $(".navigate, .logo, .cart").toggleClass('onStage');
    });

    document.getElementById("logo").addEventListener('click', function(event) {
        $(".navigate, .logo, .cart").removeClass('onStage');
    });



// ==============================================================================================

});








