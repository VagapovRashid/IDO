// JavaScript Document



var dataProduct = JSON.parse(localStorage.getItem('storage_dataProduct'));

var selectedProd = localStorage.getItem('storage_selectedProd');

var prodOrdered = ( dataProduct[selectedProd].order>0 ) ? 'inOrder' : '';




// ==============================================================================================  Keyboard Show Close Press Key
// ==============================================================================================   
// ==============================================================================================  
var inputRem = '',
    inputNew = '';
var activeInputField,
    typeKeyInput;


function KeyboardShow() {
    var inputPos = activeInputField.offset(),
        inputTop = inputPos.top,
        inputLeft = inputPos.left,
        inputWidth = activeInputField.outerWidth();
    var keyboardLeft = 0,
        keyboardTop = 0,
        keyboardSide = '';                                                                                          console.log( 'KeyboardShow inputPos = '+inputLeft+" "+inputTop );

    document.getElementById("keyboard").className = "keyboard";

    if( inputLeft>450 ) {
        keyboardLeft = inputLeft-242;
        keyboardSide = 'from_left';
    }else {
        keyboardLeft = inputLeft+inputWidth+21;
        keyboardSide = 'from_right';
    };                                                                                                              console.log( 'KeyboardShow keyboardPos = '+keyboardLeft+" "+keyboardSide );

    if( inputTop<180 ) {
        keyboardTop = 30;
        $(".keyboard .arrow").css({"top":(inputTop-30+18)+'px'});
    }else if( inputTop>608 ) {
        keyboardTop = 462;
        $(".keyboard .arrow").css({"top":(inputTop-462+18)+'px'});
    }else {
        keyboardTop = inputTop-130;
        $(".keyboard .arrow").css({"top":'50%'});
    };                                                                                                              console.log( 'KeyboardShow keyboardPos = '+keyboardTop );

    $(".keyboard").css({"left":keyboardLeft+'px', "top":keyboardTop+'px'});
    $(".keyboard").addClass(keyboardSide).addClass("show");
    setTimeout( function() {
        $(".keyboard_over").addClass("active");
    }, 200);
};


function KeyboardClose() {
    $(".keyboard").css({"left":'0px', "top":'-3000px'});
    document.getElementById("keyboard").className = "keyboard";
    $(".keyboard .symb").removeClass("press");
    $(".qte .input").removeClass("active_input");
    $(".keyboard_over").removeClass("active");

    if( inputRem=='' ) {
        inputRem = '0';
        $("#input_"+selectedProd).html(inputRem);
    };
                                                                                                                        console.log( 'selectedProd = '+selectedProd );
    $("#input_"+selectedProd).attr({"data-val": parseInt(inputRem)});
    $("#hammer_"+selectedProd).attr({"data-val": parseInt(inputRem)});

    dataProduct[selectedProd].order = parseInt(inputRem);
    localStorage.setItem('storage_dataProduct', JSON.stringify(dataProduct));

    if( dataProduct[selectedProd].order>0 ) $(".item_slider").addClass('inOrder');
    else                                    $(".item_slider").removeClass("inOrder");
};


function KeyboardPress(objKey) {
    var symbValue = objKey.getAttribute("data-symb");

    $(".keyboard span").removeClass("press");
    objKey.className += ' press';

    switch (symbValue) {
        case 'c':
            inputNew = inputRem.slice(0, -1);
            inputRem = inputNew;
            break;
        case 'x':
            KeyboardClose();
            break;
        default:
            inputNew = inputRem + symbValue;
            if( inputNew.length==2 && inputNew.substr(0, 1)=='0' ) {
                inputRem = inputNew.substr(1);
            }
            else if( inputNew.length>3 ) {
                inputRem = inputNew.substr(0, 3);
            }
            else inputRem = inputNew;
    };
    activeInputField.html(inputRem);

};


function Keyboard() {
    activeInputField = $(".qte .active_input");
    inputRem = activeInputField.attr("data-val");
    inputNew = '';                                                                                                       console.log( 'Keyboard inputRem = '+inputRem );
    KeyboardShow();
};


function InitKeyInput(objInput, typeInput) {                                                                                console.log("InitKeyInput!!!");

    objInput.on("click", function(e){

        $(".qte .input").removeClass("active_input");
        objInput.addClass("active_input");

        typeKeyInput = typeInput;
        selectedProd = parseInt(objInput.attr("data-index"));                                                               console.log( 'selectedProd = '+selectedProd );
        Keyboard();
    });
};
// ==============================================================================================  
// ==============================================================================================  
// ==============================================================================================  





// ==============================================================================================  Init  Scroller
var scrollerProd;


function InitScroller() {

    scrollerProd = new IScroll('#scroller_product', {
        scrollbars: false,
        click: true,
    });

};



// ==============================================================================================  Field Hammer
var EV_deltaX = 0;

function FieldHammer(el, topLimit, Step, Inter) {
    var mc = new Hammer(el, {});

    var singleTap = new Hammer.Tap({ event: 'singletap' });
    var onlyPan = new Hammer.Pan({event: 'onlypan' });
    mc.add([onlyPan, singleTap]);
    singleTap.requireFailure(onlyPan);

    mc.get('pan').set({ direction: Hammer.DIRECTION_HORIZONTAL });

    mc.on("tap", function(ev) {
        ev.preventDefault();
    });

    mc.on("panleft", function(ev) {
        ev.preventDefault();
        var valFieldHammer = parseInt(el.getAttribute('data-val'));
        var $FieldInput = $("#"+el.getAttribute('data-connect'));

        if( Math.abs(ev.deltaX-EV_deltaX)>Inter ) {
            EV_deltaX = ev.deltaX;
            valFieldHammer = valFieldHammer - Step;
            valFieldHammer = ( valFieldHammer<0 ) ? 0 : valFieldHammer;

            el.setAttribute('data-val', valFieldHammer);
            $FieldInput.attr({"data-val": valFieldHammer}).html(valFieldHammer);
        };
    });

    mc.on("panright", function(ev) {
        ev.preventDefault();
        var valFieldHammer = parseInt(el.getAttribute('data-val'));
        var $FieldInput = $("#"+el.getAttribute('data-connect'));

        if( Math.abs(ev.deltaX-EV_deltaX)>Inter ) {
            EV_deltaX = ev.deltaX;
            valFieldHammer = valFieldHammer + Step;
            valFieldHammer = ( valFieldHammer>topLimit ) ? topLimit : valFieldHammer;

            el.setAttribute('data-val', valFieldHammer);
            $FieldInput.attr({"data-val": valFieldHammer}).html(valFieldHammer);                                                                 // console.log(valHammer);
        };
    });

    mc.on("panend", function(ev) {
        EV_deltaX = 0;																										console.log("panend");
        var valFieldHammer = parseInt(el.getAttribute('data-val'));
        var prodIndex = parseInt(el.getAttribute('data-index'));

        dataProduct[prodIndex].order = valFieldHammer;
        localStorage.setItem('storage_dataProduct', JSON.stringify(dataProduct));

        if( valFieldHammer>0 ) $(".item_slider").addClass('inOrder');
        else                   $(".item_slider").removeClass('inOrder');

    });
};



// ========================================================================================================== Init Tumb
function InitTumb(objTumb) {

    objTumb.on("click", function(ev) {
        var indexTumb = $('ul.tumb li').index(objTumb);

        $('ul.tumb li').removeClass("active");
        objTumb.addClass("active");

        $('ul.scroller_visual').css({"-webkit-transform": 'translate3d(-'+ (indexTumb*340) +'px,0,0)'});
    });
};



// ===================================================================================================  Load Catalog
function LoadItem() {
    var visualHTML = '';

    $(".product").attr({
        "id": "product_"+selectedProd,
        "data-index": selectedProd,
        "data-cat": dataProduct[selectedProd].category
    });

    $(".product h4").html('<span>'+dataProduct[selectedProd].name+'</span><span>€ '+dataProduct[selectedProd].price+'</span>');

    $(".product .parametr").html('<span>'+ dataProduct[selectedProd].subname +'</span><span>'+ dataProduct[selectedProd].format +'</span>');

    $(".product .desc").html(dataProduct[selectedProd].desc);

    $(".qte .input").attr({
        "id": "input_"+selectedProd,
        "data-index": selectedProd,
        "data-connect": "hammer_"+selectedProd,
        "data-val": dataProduct[selectedProd].order
    }).html(dataProduct[selectedProd].order);

    $(".hammer").attr({
        "id": "hammer_"+selectedProd,
        "data-index": selectedProd,
        "data-connect": "input_"+selectedProd,
        "data-val": dataProduct[selectedProd].order
    });


    for(var j = 0; j < dataProduct[selectedProd].image.length; j++) {
        visualHTML += '<li><img class="visual_img" src="images/product/'+ dataProduct[selectedProd].category +'/'+ dataProduct[selectedProd].image[j] +'"></li>';
    };
    $(".scroller_visual").html(visualHTML);

    $("ul.tumb").html(visualHTML);
    $("ul.tumb li").addClass("visual_tumb");
    $("ul.tumb li:first-child").addClass("active");

    $(".visual_tumb").each(function( index ) {
        InitTumb($(this));
    });


    FieldHammer(document.getElementById("hammer_"+selectedProd), 999, 1, 20);
    InitKeyInput($("#input_"+selectedProd), 'string');


    setTimeout( function() {
        scrollerProd.refresh();
    }, 300);
};






// ==============================================================================================
// ==============================================================================================
// ==============================================================================================

$(document).ready(function(){

// ==============================================================================================  SETUP
    setTimeout( function() {
        InitScroller();
    }, 100);


    LoadItem();

    $(".item_slider").addClass(prodOrdered);
    $(".star_list li:nth-child("+ dataProduct[selectedProd].rate +")").addClass('active').prevAll('li.star').addClass('active');

    var indexSlide = localStorage.getItem('storage_indexSlide');
    $(".btn_back").attr({"href": "#slide"+indexSlide});



// ==============================================================================================  Keyboard
    var symbBtns = getElementsByClassName("symb");
    ///////////////////////////////////
    for(var i = 0; i < symbBtns.length; i++) {
        symbBtns[i].addEventListener('click', function(event) {
            KeyboardPress(this);
        });
    };

    document.getElementById("keyboard_over").addEventListener('click', function(event) {
        KeyboardClose();
    });



// ======================================================================================== jQ Rate
    var offset = $('.star_list').offset(),
        wrapperObj;

    $(".star_list").draggable({
        axis: "x",
        containment:"parent",
        revert: true,
        revertDuration:10,
        start: function( event, ui ) {
            offset = $(this).offset();
            wrapperObj = $(this);
        },
        drag: function( event, ui ) {
            var draggMove = event.pageX,
                starMark = 0,																				            //console.log(draggMove);
                calibre = 42;  // width of star

            starMark = Math.round((Math.abs(draggMove-offset.left))/calibre)+1;

            $(".star_list li").removeClass('active');
            if ( starMark>5 ) {
                $(".star_list li").addClass('active');
                dataProduct[selectedProd].rate = 5;
            }else {
                $('.star_list  li:nth-child('+starMark+')').prevAll('li.star').addClass('active');
                dataProduct[selectedProd].rate = starMark-1;
            };
            localStorage.setItem('storage_dataProduct', JSON.stringify(dataProduct));
        }
    });


    var starBtns = getElementsByClassName("star");
    ///////////////////////////////////
    for(var i = 0; i < starBtns.length; i++) {
        starBtns[i].addEventListener('click', function(event) {
            var indexBtn = starBtns.indexOf(this);

            $(".star_list li").removeClass('active');
            $(".star_list li:nth-child("+ (indexBtn+1) +")").addClass('active').prevAll('li.star').addClass('active');

            dataProduct[selectedProd].rate = indexBtn+1;
            localStorage.setItem('storage_dataProduct', JSON.stringify(dataProduct));
        });
    };


// ==============================================================================================

});








