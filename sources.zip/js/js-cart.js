// JavaScript Document


var dataProduct = JSON.parse(localStorage.getItem('storage_dataProduct')); 											//console.log(JSON.stringify(dataProduct));

var totalDiscount = parseInt(localStorage.getItem('storage_totalDiscount'));
var totalPrice = 0;

var CartHTML = '';
var TotalHTML = '';

var selectedProd = 0;


// ==============================================================================================                                 Summary
function Summary() {
	var totalInCart = 0;
	totalPrice = 0;

    for(var z = 0; z < dataProduct.length; z++) {
        if( dataProduct[z].order>0 ) {
            totalInCart ++;
            totalPrice += dataProduct[z].order * dataProduct[z].price;
        };
    };
	localStorage.setItem('storage_totalPrice', totalPrice);

	$("#subtotal").html(totalPrice.toFixed(2));
	$("#total").html( (totalPrice - totalPrice*(totalDiscount*0.01)).toFixed(2) );
};



// ==============================================================================================  Keyboard Show Close Press Key
// ==============================================================================================
// ==============================================================================================
var inputRem = '',
    inputNew = '';
var activeInputField,
    typeKeyInput;


function KeyboardShow() {
    var inputPos = activeInputField.offset(),
        inputTop = inputPos.top,
        inputLeft = inputPos.left,
        inputWidth = activeInputField.outerWidth();
    var keyboardLeft = 0,
        keyboardTop = 0,
        keyboardSide = '';                                                                                          console.log( 'KeyboardShow inputPos = '+inputLeft+" "+inputTop );

    document.getElementById("keyboard").className = "keyboard";

    if( inputLeft>450 ) {
        keyboardLeft = inputLeft-242;
        keyboardSide = 'from_left';
    }else {
        keyboardLeft = inputLeft+inputWidth+21;
        keyboardSide = 'from_right';
    };                                                                                                              console.log( 'KeyboardShow keyboardPos = '+keyboardLeft+" "+keyboardSide );

    if( inputTop<180 ) {
        keyboardTop = 30;
        $(".keyboard .arrow").css({"top":(inputTop-30+18)+'px'});
    }else if( inputTop>608 ) {
        keyboardTop = 462;
        $(".keyboard .arrow").css({"top":(inputTop-462+18)+'px'});
    }else {
        keyboardTop = inputTop-130;
        $(".keyboard .arrow").css({"top":'50%'});
    };                                                                                                              console.log( 'KeyboardShow keyboardPos = '+keyboardTop );

    $(".keyboard").css({"left":keyboardLeft+'px', "top":keyboardTop+'px'});
    $(".keyboard").addClass(keyboardSide).addClass("show");
    setTimeout( function() {
        $(".keyboard_over").addClass("active");
    }, 200);
};


function KeyboardClose() {
    $(".keyboard").css({"left":'0px', "top":'-3000px'});
    document.getElementById("keyboard").className = "keyboard";
    $(".keyboard .symb").removeClass("press");
    $(".qte.input").removeClass("active_input");
    $(".keyboard_over").removeClass("active");

    if( inputRem=='' ) {
        inputRem = '0';
        $("#input_"+selectedProd).html(inputRem);
    };
    console.log( 'selectedProd = '+selectedProd );
    $("#input_"+selectedProd).attr({"data-val": parseInt(inputRem)});
    $("#hammer_"+selectedProd).attr({"data-val": parseInt(inputRem)});

    dataProduct[selectedProd].order = parseInt(inputRem);
    localStorage.setItem('storage_dataProduct', JSON.stringify(dataProduct));
    Summary();

    if( dataProduct[selectedProd].order<1 ) {
        activeInputField.closest(".product").remove();
        setTimeout( function() {
            scrollerOrder.refresh();
        }, 300);
    }
};


function KeyboardPress(objKey) {
    var symbValue = objKey.getAttribute("data-symb");

    $(".keyboard span").removeClass("press");
    objKey.className += ' press';

    switch (symbValue) {
        case 'c':
            inputNew = inputRem.slice(0, -1);
            inputRem = inputNew;
            break;
        case 'x':
            KeyboardClose();
            break;
        default:
            inputNew = inputRem + symbValue;
            if( inputNew.length==2 && inputNew.substr(0, 1)=='0' ) {
                inputRem = inputNew.substr(1);
            }
            else if( inputNew.length>3 ) {
                inputRem = inputNew.substr(0, 3);
            }
            else inputRem = inputNew;
    };
    activeInputField.html(inputRem);
};


function Keyboard() {
    activeInputField = $(".qte.active_input");
    inputRem = activeInputField.attr("data-val");
    inputNew = '';                                                                                                       console.log( 'Keyboard inputRem = '+inputRem );
    KeyboardShow();
};


function InitKeyInput(objInput, typeInput) {                                                                                console.log("InitKeyInput!!!");

    objInput.on("click", function(e){

        $(".qte.input").removeClass("active_input");
        objInput.addClass("active_input");

        typeKeyInput = typeInput;
        selectedProd = parseInt(objInput.attr("data-index"));                                                               console.log( 'selectedProd = '+selectedProd );
        Keyboard();
    });
};
// ==============================================================================================
// ==============================================================================================
// ==============================================================================================



// ==============================================================================================  Scroller
var scrollerOrder;

function loadedScroller() {
	scrollerOrder = new IScroll('#order_list', {
		scrollbars: false,
		click: true
	});
};




// ==============================================================================================  Field Hammer
var EV_deltaX = 0;

function FieldHammer(el, topLimit, Step, Inter) {
	var mc = new Hammer(el, {});

	var singleTap = new Hammer.Tap({ event: 'singletap' });
	var onlyPan = new Hammer.Pan({event: 'onlypan' });
	mc.add([onlyPan, singleTap]);
	singleTap.requireFailure(onlyPan);

	mc.get('pan').set({ direction: Hammer.DIRECTION_HORIZONTAL });

	mc.on("tap", function(ev) {
		ev.preventDefault();
	});

	mc.on("panleft", function(ev) {
		ev.preventDefault();
		var valFieldHammer = parseInt(el.getAttribute('data-val'));
		var $FieldInput = $("#"+el.getAttribute('data-connect'));

		if( Math.abs(ev.deltaX-EV_deltaX)>Inter ) {
			EV_deltaX = ev.deltaX;
			valFieldHammer = valFieldHammer - Step;
			valFieldHammer = ( valFieldHammer<0 ) ? 0 : valFieldHammer;

			el.setAttribute('data-val', valFieldHammer);
			$FieldInput.attr({"data-val": valFieldHammer}).html(valFieldHammer);
		};
	});

	mc.on("panright", function(ev) {
		ev.preventDefault();
		var valFieldHammer = parseInt(el.getAttribute('data-val'));
		var $FieldInput = $("#"+el.getAttribute('data-connect'));

		if( Math.abs(ev.deltaX-EV_deltaX)>Inter ) {
			EV_deltaX = ev.deltaX;
			valFieldHammer = valFieldHammer + Step;
			valFieldHammer = ( valFieldHammer>topLimit ) ? topLimit : valFieldHammer;

			el.setAttribute('data-val', valFieldHammer);
			$FieldInput.attr({"data-val": valFieldHammer}).html(valFieldHammer);                                                                 // console.log(valHammer);
		};
	});

	mc.on("panend", function(ev) {
		EV_deltaX = 0;																										console.log("panend");
		var valFieldHammer = parseInt(el.getAttribute('data-val'));
		var prodIndex = parseInt(el.getAttribute('data-index'));

		dataProduct[prodIndex].order = valFieldHammer;
		localStorage.setItem('storage_dataProduct', JSON.stringify(dataProduct));

		if( valFieldHammer==0 ) {
			$("#hammer_"+ prodIndex).closest(".product").remove();
			setTimeout( function() {
				scrollerOrder.refresh();
			}, 300);
		};
		Summary();
		$("#btn_submit").removeClass("send");
	});
};



// ==============================================================================================   Field Hammer Discount
function FieldHammerDiscount(el, topLimit, Step, Inter) {
	var mc = new Hammer(el, {});

	var singleTap = new Hammer.Tap({ event: 'singletap' });
	var onlyPan = new Hammer.Pan({event: 'onlypan' });
	mc.add([onlyPan, singleTap]);
	singleTap.requireFailure(onlyPan);

	mc.get('pan').set({ direction: Hammer.DIRECTION_HORIZONTAL });

	mc.on("tap", function(ev) {
		ev.preventDefault();
	});

	mc.on("panleft", function(ev) {
		ev.preventDefault();
		var valFieldHammer = parseInt(el.getAttribute('data-val'));
		var $FieldInput = $("#"+el.getAttribute('data-connect'));

		if( Math.abs(ev.deltaX-EV_deltaX)>Inter ) {
			EV_deltaX = ev.deltaX;
			valFieldHammer = valFieldHammer - Step;
			valFieldHammer = ( valFieldHammer<0 ) ? 0 : valFieldHammer;

			el.setAttribute('data-val', valFieldHammer);
			$FieldInput.attr({"data-val": valFieldHammer}).html(valFieldHammer);

			totalDiscount = valFieldHammer;
			$("#input_discount0").html(totalDiscount);
			$("#total").html((totalPrice - totalPrice*(totalDiscount*0.01)).toFixed(2));
			localStorage.setItem('storage_totalDiscount', totalDiscount);
		};
	});

	mc.on("panright", function(ev) {
		ev.preventDefault();
		var valFieldHammer = parseInt(el.getAttribute('data-val'));
		var $FieldInput = $("#"+el.getAttribute('data-connect'));

		if( Math.abs(ev.deltaX-EV_deltaX)>Inter ) {
			EV_deltaX = ev.deltaX;
			valFieldHammer = valFieldHammer + Step;
			valFieldHammer = ( valFieldHammer>topLimit ) ? topLimit : valFieldHammer;

			el.setAttribute('data-val', valFieldHammer);
			$FieldInput.attr({"data-val": valFieldHammer}).html(valFieldHammer);

			totalDiscount = valFieldHammer;
			$("#input_discount0").html(totalDiscount);
			$("#total").html((totalPrice - totalPrice*(totalDiscount*0.01)).toFixed(2));
			localStorage.setItem('storage_totalDiscount', totalDiscount);
		};
	});

	mc.on("panend", function(ev) {
		EV_deltaX = 0;																										console.log("panend");
		totalDiscount = parseInt(el.getAttribute('data-val'));

		Summary();

		$("#btn_submit").removeClass("send");
		localStorage.setItem('storage_totalDiscount', totalDiscount);
	});
};



// ==============================================================================================                                   Delete Product
function DeleteProduct( objDelete ) {

	objDelete.on("click", function(e){
		var $objProd = objDelete.closest(".product");
		var prodIndex = parseInt($objProd.attr('data-index'));

		$objProd.remove();

		dataProduct[prodIndex].order = 0;
		localStorage.setItem('storage_dataProduct', JSON.stringify(dataProduct));
		Summary();

		setTimeout( function() {
			scrollerOrder.refresh();
		}, 200);
		$("#btn_submit").removeClass("send");
	});
};



// ==============================================================================================   Load Order
function LoadOrder() {
	var OrderHTML = '';
	var ParamHTML = '';

    for(var j = 0; j < dataProduct.length; j++) {

        if( dataProduct[j].order>0 ) {

            OrderHTML += '<div class="product" data-index="'+ j +'">' +
                                '<img class="product_img" src="images/product/'+ dataProduct[j].category +'/'+ dataProduct[j].image[0] +'">' +
                                '<div class="product_title">' +
                                    '<h4>'+ dataProduct[j].name +'</h4> ' +
                                    '<span>'+ dataProduct[j].subname +'</span>' +
                                '</div>' +
                                '<div class="product_price">€ '+ (dataProduct[j].price).toFixed(2) +'</div> ' +
                                '<div class="qte input" id="input_'+ j +'" data-connect="hammer_'+ j +'" data-index="'+j+'" data-val="'+ dataProduct[j].order +'">'+
                                    dataProduct[j].order +
                                '</div>' +
                                '<div class="product_total">€ '+ ((dataProduct[j].price)*dataProduct[j].order).toFixed(2) +'</div> ' +
                                '<div class="product_delete"></div>' +
                                '<div class="hammer" id="hammer_'+ j +'" data-connect="input_'+ j +'" data-index="'+j+'" data-val="'+dataProduct[j].order+'"></div>' +
                            '</div>';
        };// if
    };// for

	$("#order_list .scroller").html(OrderHTML);

	$("#order_list .hammer").each(function( ind ) {
		var idFieldHammer = $(this).attr("id");
		FieldHammer(document.getElementById(idFieldHammer), 999, 1, 10);
	});

    $("#order_list .qte").each(function( index ) {
        InitKeyInput($(this), 'string');
    });

    $("#order_list .product_delete").each(function( index ) {
		DeleteProduct($(this));
	});
	
	Summary();

	setTimeout( function() {
		scrollerOrder.refresh();
		scrollerOrder.scrollTo(0, 0, 700, IScroll.utils.ease.back);
	}, 300);
};






// ==============================================================================================
// ==============================================================================================
// ==============================================================================================

$(document).ready(function(){

// ==============================================================================================                             SETUP
	setTimeout( function() {
		loadedScroller();
	}, 100);

	$("#input_discount0").html(totalDiscount);

	LoadOrder();

	FieldHammerDiscount(document.getElementById("hammer_discount0"), 99, 1, 20);



// ==============================================================================================  Keyboard
	var symbBtns = getElementsByClassName("symb");
	///////////////////////////////////
	for(var i = 0; i < symbBtns.length; i++) {
		symbBtns[i].addEventListener('click', function(event) {
			KeyboardPress(this);
		});
	};

	document.getElementById("keyboard_over").addEventListener('click', function(event) {
		KeyboardClose();
	});




// ==============================================================================================  checkout
	document.getElementById("btn_submit").addEventListener('click', function(event) {
		this.className += ' send' ;

		CartHTML = $('.scroller').html();
		TotalHTML = $('aside').html();

		localStorage.setItem('storage_CartHTML', CartHTML);
		localStorage.setItem('storage_TotalHTML', TotalHTML);
	});



// ==============================================================================================


});





